﻿namespace WpfApp1
{
    using System;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Media;
    using System.Windows.Shapes;

    public class Körte
    {
        public Path OuterShape { get; private set; }
        public Path LeafShape { get; private set; }
        private Canvas canvas;
        private Random random = new Random();

        public event Action<Körte> OnKörteDisappeared;  // Esemény, amikor a körte eltűnik

        public Körte(Canvas canvas, double left, double top)
        {
            this.canvas = canvas;

            // Véletlenszerű méret generálása (60-100 közötti érték)
            double size = random.Next(60, 101); // Generálj véletlenszerű méretet 60 és 100 között

            // Véletlenszerű hely pozicionálása (X és Y irányban, figyelve a vászon méretére)
            double positionX = random.Next(0, (int)(canvas.Width - size));
            double positionY = random.Next(0, (int)(canvas.Height - size));

            // Körte alakú külső forma
            OuterShape = CreateKörte(size);

            // Levél készítése a körtéhez
            LeafShape = CreateLeaf();

            // Kattintás esemény hozzáadása
            OuterShape.MouseLeftButtonDown += Shape_MouseLeftButtonDown;
            LeafShape.MouseLeftButtonDown += Shape_MouseLeftButtonDown;

            // Körte pozicionálása
            SetPosition(positionX, positionY);
        }

        // Körte pozicionálása véletlenszerűen a vásznon
        private void SetPosition(double left, double top)
        {
            // Külső körte forma pozicionálása
            Canvas.SetLeft(OuterShape, left);
            Canvas.SetTop(OuterShape, top);

            // Levél pozicionálása a körte tetejére
            double leafLeft = left + OuterShape.RenderSize.Width * 0.5;
            double leafTop = top - OuterShape.RenderSize.Height * 0.2;
            Canvas.SetLeft(LeafShape, leafLeft);
            Canvas.SetTop(LeafShape, leafTop);

            // Elemek hozzáadása a vászonhoz
            canvas.Children.Add(OuterShape);
            canvas.Children.Add(LeafShape);
        }

        // Körte alak létrehozása egy path segítségével
        private Path CreateKörte(double size)
        {
            // Körte alakzat létrehozása PathGeometry-vel
            var körtePath = new Path
            {
                Fill = Brushes.GreenYellow,  // Körte színe
                Data = Geometry.Parse("M 50,10 C 40,10 30,20 30,40 C 30,60 50,90 50,90 C 50,90 70,60 70,40 C 70,20 60,10 50,10 Z"), // Körte alakzat
                Width = size,
                Height = size
            };

            return körtePath;
        }

        // Levél létrehozása (ugyanaz, mint az alma esetében)
        private Path CreateLeaf()
        {
            var leaf = new Path
            {
                Fill = Brushes.Green,
                Data = Geometry.Parse("M 0,10 Q 10,0 20,10 Q 10,20 0,10 Z"), // Levél alakzat
                RenderTransform = new RotateTransform(45), // 45 fokos forgatás
            };
            return leaf;
        }

        // Kattintásra eltüntetjük a körtét, és jelezzük a főprogramnak
        private void Shape_MouseLeftButtonDown(object sender, RoutedEventArgs e)
        {
            // Eltüntetjük a körtét
            canvas.Children.Remove(OuterShape);
            canvas.Children.Remove(LeafShape);

            // Ha van eseménykezelő, akkor értesítjük
            OnKörteDisappeared?.Invoke(this);
        }
    }
}
