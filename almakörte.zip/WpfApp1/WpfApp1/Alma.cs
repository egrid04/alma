﻿
namespace WpfApp1
{
    using System;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Media;
    using System.Windows.Shapes;

    public class Alma
    {
        public Ellipse OuterShape { get; private set; }
        public Ellipse InnerShape { get; private set; }
        public Path LeafShape { get; private set; }
        private Canvas canvas;
        private Random random = new Random();

        public event Action<Alma> OnAlmaDisappeared;  // Esemény, amikor az alma eltűnik

        public Alma(Canvas canvas, double left, double top)
        {
            this.canvas = canvas;

            // Véletlenszerű méret generálása (60-100 közötti érték)
            double size = random.Next(60, 101); // Generálj véletlenszerű méretet 60 és 100 között

            // Véletlenszerű hely pozicionálása (X és Y irányban, figyelve a vászon méretére)
            double positionX = random.Next(0, (int)(canvas.Width - size));
            double positionY = random.Next(0, (int)(canvas.Height - size));

            // Külső kör (alma egyik fele)
            OuterShape = new Ellipse
            {
                Width = size,
                Height = size,
                Fill = Brushes.Red,
                StrokeThickness = 0 // Nincs keret
            };

            // Belső kör (alma másik fele - 20%-os eltolással)
            InnerShape = new Ellipse
            {
                Width = size,
                Height = size,
                Fill = Brushes.Red,
                StrokeThickness = 0 // Nincs keret
            };

            // Levél készítése az általad megadott alakzattal
            LeafShape = CreateLeaf();

            // Kattintás esemény hozzáadása
            OuterShape.MouseLeftButtonDown += Shape_MouseLeftButtonDown;
            InnerShape.MouseLeftButtonDown += Shape_MouseLeftButtonDown;
            LeafShape.MouseLeftButtonDown += Shape_MouseLeftButtonDown;

            // Alma pozicionálása
            SetPosition(positionX, positionY);
        }

        // Alma pozicionálása véletlenszerűen a vásznon
        private void SetPosition(double left, double top)
        {
            // Külső kör pozicionálása
            Canvas.SetLeft(OuterShape, left);
            Canvas.SetTop(OuterShape, top);

            // Belső kör pozicionálása 20% vízszintes eltolással
            double innerLeft = left + OuterShape.Width * 0.2;  // 20% eltolás
            double innerTop = top;
            Canvas.SetLeft(InnerShape, innerLeft);
            Canvas.SetTop(InnerShape, innerTop);

            // Levél pozicionálása az alma tetejére (két kör metszési pontjára)
            double leafLeft = left + OuterShape.Width * 0.5;  // Alma széle (a két kör metszése)
            double leafTop = top - OuterShape.Height *0.25;    // Levél elhelyezése az alma tetején (lejjebb)
            Canvas.SetLeft(LeafShape, leafLeft);
            Canvas.SetTop(LeafShape, leafTop);

            // Elemek hozzáadása a vászonhoz
            canvas.Children.Add(OuterShape);
            canvas.Children.Add(InnerShape);
            canvas.Children.Add(LeafShape);
        }

        // Levél létrehozása az általad megadott alakzattal, és duplázott méret
        private Path CreateLeaf()
        {
            var leaf = new Path
            {
                Fill = Brushes.Green,
                Data = Geometry.Parse("M 0,10 Q 10,0 20,10 Q 10,20 0,10 Z"), // Levél alakzat
                RenderTransform = new RotateTransform(45), // 45 fokos forgatás
               // Width = 40, // Levél szélessége
                //Height = 40  // Levél magassága (dupla méret)
            };
            return leaf;
        }

        // Kattintásra eltüntetjük az almát, és jelezzük a főprogramnak
        private void Shape_MouseLeftButtonDown(object sender, RoutedEventArgs e)
        {
            // Eltüntetjük az almát
            canvas.Children.Remove(OuterShape);
            canvas.Children.Remove(InnerShape);
            canvas.Children.Remove(LeafShape);

            // Ha van eseménykezelő, akkor értesítjük
            OnAlmaDisappeared?.Invoke(this);
        }
    }


}