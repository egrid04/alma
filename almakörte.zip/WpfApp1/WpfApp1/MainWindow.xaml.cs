﻿using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int visibleItems = 0;
        private int visibleItems2 = 0;
        Random random = new Random();
        public MainWindow()
        {
            InitializeComponent();
            /*canvas = new Canvas();
            this.Content = canvas;
            canvas.Width = 800;
            canvas.Height = 400;
            Alma a1 = new Alma(canvas, 400, 400);*/
            db.Text = "Alma";
            KörteCountTextBox.Text = "Körte";
        }
        private void general(object sender, RoutedEventArgs e)
        {
            int darab = Int32.Parse(db.Text);
            for (int i = 0; i < darab; i++)
            {
                Alma alma = new Alma(canvas, random.Next(0, (int)canvas.Width - 100), random.Next(0, (int)canvas.Height - 100));
                alma.OnAlmaDisappeared += Alma_OnDisappeared;
                visibleItems++;
            }
            UpdateLabelCounter();
        }

        private void GenerateKörte_Click(object sender, RoutedEventArgs e)
        {
            int darab = Int32.Parse(KörteCountTextBox.Text);
            for (int i = 0; i < darab; i++)
            {
                Körte körte = new Körte(canvas, random.Next(0, (int)canvas.Width - 100), random.Next(0, (int)canvas.Height - 100));
                körte.OnKörteDisappeared += Körte_OnDisappeared;
                visibleItems2++;
            }
            UpdateLabelCounter();
        }
        private void Alma_OnDisappeared(Alma alma)
        {
            visibleItems--;
            UpdateLabelCounter();
        }

        // Körte eltűnésének kezelése
        private void Körte_OnDisappeared(Körte körte)
        {
            visibleItems2--;
            UpdateLabelCounter();
        }

        // Címke frissítése a látható elemek számával
        private void UpdateLabelCounter()
        {
            LabelCounter.Content = $"Almák: {visibleItems}, Körték: {visibleItems2}";
        }


    }
}